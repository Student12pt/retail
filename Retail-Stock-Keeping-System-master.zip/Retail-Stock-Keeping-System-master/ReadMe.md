Implementation of a retail stock keeping system to keep track of inventory.
The underlying data structure is a self balancing red black tree *(https://en.wikipedia.org/wiki/Red%E2%80%93black_tree)*

**Compile:**
Simply type make to compile the source code for the Retail Stock Keeping System.